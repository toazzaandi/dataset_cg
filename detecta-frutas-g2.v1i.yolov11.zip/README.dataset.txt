# detecta-frutas-g2 > 2024-11-12 10:25pm
https://universe.roboflow.com/deteccaofrutasg2/detecta-frutas-g2

Provided by a Roboflow user
License: CC BY 4.0

